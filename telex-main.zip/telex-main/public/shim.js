// Replaces Claude's built-in database with this server's API.
(()=>{const T=()=>localStorage.getItem('tx_admin')||'',H=()=>({'Content-Type':'application/json','x-admin':T()});
const j=async(u,o={})=>{const r=await fetch(u,{...o,headers:H()});if(!r.ok)throw{code:'denied',message:'Not allowed'};return r.json()};
const snap=(id,d)=>({id,exists:!!d,data:()=>d});
const poll=(fn,next,err)=>{let on=1,last='';const go=async()=>{try{const v=await fn();const s=JSON.stringify(v);if(s!==last){last=s;next(v)}}catch(e){err&&err(e)}if(on)setTimeout(go,3000)};go();return()=>{on=0}};
const doc=p=>({id:p.split('/').pop(),path:p,
 get:async()=>{const r=await j('/api/doc?path='+p);return snap(p.split('/').pop(),r.exists?r.data:null)},
 set:d=>j('/api/doc?path='+p,{method:'PUT',body:JSON.stringify(d)}),update:d=>j('/api/doc?path='+p,{method:'PATCH',body:JSON.stringify(d)}),delete:()=>j('/api/doc?path='+p,{method:'DELETE'}),
 onSnapshot:(n,e)=>poll(async()=>(await j('/api/doc?path='+p)),r=>n(snap(p.split('/').pop(),r.exists?r.data:null)),e)});
const col=n=>({add:async d=>doc(n+'/'+(await j('/api/col/'+n,{method:'POST',body:JSON.stringify(d)})).id),
 onSnapshot:(nx,e)=>poll(()=>j('/api/col/'+n),a=>{const docs=a.map(({id,...d})=>snap(id,d));nx({docs,size:docs.length,empty:!docs.length})},e)});
let admin=false;const ready=(async()=>{
  const sp=new URLSearchParams(location.search);
  const p=sp.get('admin');
  if(p&&p!=='1'&&p!=='true'){localStorage.setItem('tx_admin',p.trim())}
  else if(p&&!T()){const t=prompt('Admin token:');if(t)localStorage.setItem('tx_admin',t.trim())}
  try{
    const r=await j('/api/auth');
    admin=!!r.admin;
    if(p&&!admin){
      const retry=prompt('Admin token incorrect. Enter valid admin token:');
      if(retry){
        localStorage.setItem('tx_admin',retry.trim());
        const r2=await j('/api/auth');
        admin=!!r2.admin;
      }
    }
  }catch(e){}
})();
const uid=(()=>{let u=localStorage.getItem('tx_uid');if(!u){u=[...crypto.getRandomValues(new Uint8Array(12))].map(b=>b.toString(16).padStart(2,'0')).join('');localStorage.setItem('tx_uid',u)}return u})();
const mods={db:{doc,collection:col},user:{canEdit:async()=>(await ready,admin),isOwner:async()=>(await ready,admin),id:async()=>uid},
 downloads:{save:async({filename,data})=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data]));a.download=filename;a.click()}}};
window.claude={use:async n=>{await ready;return mods[n]||null}}})();
