# TeleX — Genuine Gadgets Storefront & Admin

Zero external npm dependencies. Built for instant deployment on **Vercel** or local Node.js.

---

## 🚀 Deploy to Vercel

### Option 1: Vercel CLI (Fastest)
1. In this directory, run:
   ```bash
   vercel
   ```
2. Follow prompts (accept defaults).
3. (Optional) Set your admin secret token in Vercel project environment variables:
   - `ADMIN_TOKEN`: `your-custom-secret` (defaults to `change-me` if unset)

### Option 2: Deploy via GitHub / GitLab / Bitbucket
1. Push this folder to a GitHub repository.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repository.
3. Framework Preset: **Other** (leave build settings empty).
4. Add Environment Variable:
   - Name: `ADMIN_TOKEN`
   - Value: `your-custom-secret`
5. Click **Deploy**.

---

## 🗄️ Database & Storage on Vercel

- **Out of the box**: Pre-seeded with catalogue and settings. Operates seamlessly in Vercel serverless mode.
- **Production Persistence (Recommended)**: For persistent storage across serverless cold starts:
  1. In your Vercel Dashboard, go to **Storage** tab.
  2. Create an **Upstash / Vercel KV** database.
  3. TeleX will automatically detect and sync with `KV_REST_API_URL` and `KV_REST_API_TOKEN` without installing any extra packages!

---

## 💻 Local Development

Requires Node 18+:

```bash
npm start
# or: ADMIN_TOKEN=my-secret node server.js
```

- Store: `http://localhost:3000`
- Admin: `http://localhost:3000/?admin=1` (or `/?admin=my-secret`)

---

## 🔑 Admin Access

- Access URL: `https://your-domain.vercel.app/?admin=1`
- Enter your `ADMIN_TOKEN` when prompted.
- You can also log in directly by visiting:
  `https://your-domain.vercel.app/?admin=YOUR_SECRET_TOKEN`
- Once authenticated, the **Admin** button appears in the footer.
- Features: Dashboard metrics, Product catalogue management, Order tracker, WhatsApp settings & CSV export.
