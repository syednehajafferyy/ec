// TeleX server: zero dependencies. Run: ADMIN_TOKEN=your-secret node server.js
const http = require('http');
const fs = require('fs');
const path = require('path');
const apiHandler = require('./api/index.js');

const PORT = process.env.PORT || 3000;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8'
};

const sendFile = (r, filePath) => {
  const ext = path.extname(filePath).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  r.writeHead(200, { 'Content-Type': type });
  r.end(fs.readFileSync(filePath));
};

async function serverHandler(q, r) {
  const u = new URL(q.url, 'http://' + (q.headers.host || 'localhost'));
  
  // If it's an API route, pass to API handler
  if (u.pathname.startsWith('/api/') || u.pathname === '/api') {
    return apiHandler(q, r);
  }

  // Look for static file in public/
  const pubDir = path.join(__dirname, 'public');
  let relPath = u.pathname === '/' ? 'index.html' : u.pathname.replace(/^\/+/, '');
  const filePath = path.join(pubDir, relPath);

  if (filePath.startsWith(pubDir) && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return sendFile(r, filePath);
  }

  // Fallback to API handler in case rewrite stripped /api
  return apiHandler(q, r);
}

if (require.main === module) {
  http.createServer(serverHandler).listen(PORT, () => {
    console.log(`TeleX running on http://localhost:${PORT}  (admin: /?admin=1)`);
  });
}

module.exports = serverHandler;
