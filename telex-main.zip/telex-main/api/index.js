// TeleX API handler: supports Vercel Serverless Functions and local Node.js
const fs = require('fs');
const path = require('path');
const os = require('os');

const TOKEN = process.env.ADMIN_TOKEN || 'change-me';
const KV_URL = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const KV_TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;

// Default catalogue and settings seed
let DEFAULT_DB = {};
try {
  DEFAULT_DB = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data.json'), 'utf8'));
} catch (e) {
  try { DEFAULT_DB = JSON.parse(fs.readFileSync(path.join(__dirname, 'data.json'), 'utf8')); } catch (e2) {}
}

let db = null;
let writablePath = null;

function getWritableFile() {
  if (writablePath) return writablePath;
  const candidates = [
    path.join(process.cwd(), 'data.json'),
    path.join(__dirname, '..', 'data.json'),
    path.join(__dirname, 'data.json')
  ];
  for (const c of candidates) {
    try {
      const dir = path.dirname(c);
      fs.accessSync(dir, fs.constants.W_OK);
      writablePath = c;
      return writablePath;
    } catch (e) {}
  }
  writablePath = path.join(os.tmpdir(), 'telex_data.json');
  return writablePath;
}

function findSeedFile() {
  const candidates = [
    path.join(__dirname, 'data.json'),
    path.join(__dirname, '..', 'data.json'),
    path.join(process.cwd(), 'data.json'),
    path.join(process.cwd(), 'telex', 'data.json'),
    path.join(__dirname, '..', 'telex', 'data.json')
  ];
  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) return c;
    } catch (e) {}
  }
  return null;
}

function initDb() {
  if (db) return db;
  const wFile = getWritableFile();
  if (fs.existsSync(wFile)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(wFile, 'utf8'));
      if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
        db = parsed;
        return db;
      }
    } catch (e) {}
  }
  const seedFile = findSeedFile();
  if (seedFile) {
    try {
      const parsed = JSON.parse(fs.readFileSync(seedFile, 'utf8'));
      if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
        db = parsed;
        return db;
      }
    } catch (e) {}
  }
  db = JSON.parse(JSON.stringify(DEFAULT_DB));
  return db;
}

async function syncKvGet() {
  if (!KV_URL || !KV_TOKEN) return;
  try {
    const res = await fetch(`${KV_URL}/get/telex_db`, {
      headers: { Authorization: `Bearer ${KV_TOKEN}` }
    });
    if (res.ok) {
      const json = await res.json();
      if (json && json.result) {
        const remote = typeof json.result === 'string' ? JSON.parse(json.result) : json.result;
        if (remote && typeof remote === 'object') {
          db = { ...(db || {}), ...remote };
        }
      }
    }
  } catch (e) {}
}

async function syncKvSet() {
  if (!KV_URL || !KV_TOKEN) return;
  try {
    await fetch(`${KV_URL}/set/telex_db`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${KV_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(db)
    });
  } catch (e) {}
}

const save = async () => {
  const target = getWritableFile();
  try {
    fs.writeFileSync(target, JSON.stringify(db, null, 2));
  } catch (e) {
    try {
      const tmp = path.join(os.tmpdir(), 'telex_data.json');
      fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
    } catch (err) {}
  }
  if (KV_URL && KV_TOKEN) {
    await syncKvSet();
  }
};

const send = (r, c, b, t = 'application/json') => {
  r.setHeader('Access-Control-Allow-Origin', '*');
  r.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  r.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-admin');
  r.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  r.writeHead(c, { 'Content-Type': t });
  r.end(typeof b === 'string' ? b : JSON.stringify(b));
};

const body = async (q) => {
  if (q.body !== undefined && q.body !== null) {
    if (typeof q.body === 'object') return q.body;
    if (typeof q.body === 'string') {
      try { return JSON.parse(q.body || '{}'); } catch(e) { return {}; }
    }
  }
  return new Promise(res => {
    let s = '';
    q.on('data', c => { s += c; if (s.length > 1e6) q.destroy(); });
    q.on('end', () => {
      try { res(JSON.parse(s || '{}')); } catch(e) { res({}); }
    });
    q.on('error', () => res({}));
  });
};

const col = n => {
  initDb();
  return Object.keys(db)
    .filter(k => k.startsWith(n + '/') && k.split('/').length === 2)
    .map(k => ({ ...db[k], id: k.split('/')[1] }));
};

async function handler(q, r) {
  initDb();
  if (KV_URL && KV_TOKEN) {
    await syncKvGet();
  }

  // Handle CORS Preflight
  r.setHeader('Access-Control-Allow-Origin', '*');
  r.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  r.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-admin');

  if (q.method === 'OPTIONS') {
    r.writeHead(204);
    return r.end();
  }

  const u = new URL(q.url, 'http://' + (q.headers.host || 'localhost'));
  const admin = q.headers['x-admin'] === TOKEN;
  const p = u.searchParams.get('path') || '';

  // Normalize pathname: works whether mounted at /api/ or rewrote to /
  let pathname = u.pathname;
  if (pathname.startsWith('/api')) {
    pathname = pathname.slice(4) || '/';
  }

  if (pathname === '/auth') {
    return send(r, 200, { admin });
  }

  if (pathname.startsWith('/col/')) {
    const n = pathname.slice(5);
    if (n === 'orders' && !admin) return send(r, 403, { error: 'admin only' });
    if (q.method === 'POST') {
      if (!admin) return send(r, 403, { error: 'admin only' });
      const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      db[n + '/' + id] = await body(q);
      await save();
      return send(r, 200, { id });
    }
    return send(r, 200, col(n));
  }

  if (pathname === '/doc') {
    const own = /^orders\/[A-Za-z0-9_-]{8,64}$/.test(p);
    if (q.method === 'GET') {
      if (p.startsWith('orders/') && !own && !admin) return send(r, 403, {});
      return send(r, 200, db[p] ? { exists: true, data: db[p] } : { exists: false });
    }
    if (!admin && !(own && q.method === 'PUT')) return send(r, 403, { error: 'not allowed' });
    if (q.method === 'PUT') {
      db[p] = await body(q);
      await save();
      return send(r, 200, { ok: 1 });
    }
    if (q.method === 'PATCH') {
      db[p] = { ...(db[p] || {}), ...await body(q) };
      await save();
      return send(r, 200, { ok: 1 });
    }
    if (q.method === 'DELETE') {
      delete db[p];
      await save();
      return send(r, 200, { ok: 1 });
    }
  }

  return send(r, 404, { error: 'Not found' });
}

module.exports = handler;
